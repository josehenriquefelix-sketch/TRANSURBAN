from pathlib import Path
import json,subprocess,sys,re,unicodedata,math,zipfile
from PIL import Image,ImageDraw,ImageFont
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'video_runtime'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
OUT=REPO/'avaliacao_integrada/docs/video'
data=json.loads((HERE/'voz.json').read_text(encoding='utf-8'))
chars=data['original_characters'];words=data['original_words']
def normal(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower()) if c.isalnum())
corpus='';indices=[]
for c in chars:
    n=normal(c['text']);corpus+=n;indices.extend([c['start_time']]*len(n))
def at(text):
    i=corpus.find(normal(text));assert i>=0,text
    return max(0,indices[i]-.15)
scenes=[
 (0,'passageiro.jpg','TRANSURBAN • conheça o sistema',0),
 (at('No passageiro, a pessoa'),'passageiro.jpg','Passageiro • cidade, bairro e linha',350),
 (at('Os horários disponíveis'),'horarios.jpg','Horários • programação e fontes',0),
 (at('Os três acessos'),'cadastro_passageiro.jpg','Criar conta • passageiro',0),
 (at('A senha precisa'),'cadastro_motorista.jpg','Criar conta • motorista',0),
 (at('Para motorista e gestão'),'cadastro_gestao.jpg','Criar conta • gestão e aprovação',0),
 (at('O motorista autorizado'),'motorista.jpg','Motorista • ônibus, linha e sentido',650),
 (at('Para compartilhar a posição'),'motorista.jpg','Viagem • GPS do dispositivo autorizado',1000),
 (at('A gestão tem um painel'),'gestao.jpg','Gestão • viagens e atendimento',0),
 (at('A gestão analisa o relato'),'gestao_mapa.jpg','Gestão • análise de ocorrências',180),
 (at('A API é a parte'),'api.jpg','API • Python e FastAPI',0),
 (at('No Swagger'),'api_cidades.jpg','Consulta real • GET /cidades retornou 200',100),
 (at('O banco PostgreSQL'),'supabase.jpg','Supabase • captura de 24/11/2026',0),
 (at('Há tabelas para cidades'),'tabelas.jpg','Banco • estrutura das 12 tabelas ativas',0),
 (at('As chaves relacionam'),'tabelas.jpg','Banco • relações e autenticação',950),
 (at('O GitHub guarda'),'github.jpg','GitHub • código e instruções',0),
 (at('Para usar em outro computador'),'github.jpg','Na escola • Git, VS Code e servidor local',1250),
 (at('O grupo também tem'),'banner.png','Equipe • roteiro sem slides e banner original',0),
 (at('A parte de Ciência de Dados'),'passageiro.jpg','Ciência de Dados • base sintética de estudo',0),
 (at('Apresentem o que está comprovado'),'passageiro.jpg','Limites • explique apenas o que foi comprovado',0),
]
duration=data['duration'];W,H,FPS=1280,720,24;VH=510
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',27)
bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',23)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
measure=ImageDraw.Draw(Image.new('RGB',(W,H)))
def wrap(text):
    lines=[];line=''
    for word in text.split():
        candidate=(line+' '+word).strip()
        if measure.textlength(candidate,font=font)>W-96 and line:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    assert len(lines)<=2,(text,lines)
    return lines
cues=[];group=[]
for word in words:
    if group and (len(' '.join(x['text'] for x in group+[word]))>102 or word['start_time']-group[0]['start_time']>5.5):
        cues.append({'start':group[0]['start_time'],'end':group[-1]['end_time'],'text':' '.join(x['text'] for x in group)});group=[]
    group.append(word)
if group:cues.append({'start':group[0]['start_time'],'end':group[-1]['end_time'],'text':' '.join(x['text'] for x in group)})
def stamp(s):
    m=round(s*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'
video=OUT/'TRANSURBAN_GUIA_NARRADO.mp4'
cmd=[FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(HERE/'narracao.wav'),'-map','0:v','-map','1:a','-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','23','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(video)]
with (HERE/'render_narrado.log').open('wb') as log:
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
    ci=0
    for index,(start,asset,title,y) in enumerate(scenes):
        end=scenes[index+1][0] if index+1<len(scenes) else duration
        source=Image.open(HERE/'fontes'/asset).convert('RGB')
        if asset.startswith('cadastro_'):
            source=source.crop((source.width//2,0,source.width,source.height))
        if asset=='banner.png':
            source.thumbnail((W,VH),Image.Resampling.LANCZOS);background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source,((W-source.width)//2,(VH-source.height)//2))
        else:
            scale=min(W/source.width,VH/source.height) if asset.startswith('cadastro_') else W/source.width
            source=source.resize((round(source.width*scale),round(source.height*scale)),Image.Resampling.LANCZOS)
            y=max(0,min(round(y*scale),source.height-VH));background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source.crop((0,y,source.width,min(y+VH,source.height))),((W-source.width)//2,0))
        for frameNo in range(round(start*FPS),round(end*FPS)):
            t=frameNo/FPS
            while ci+1<len(cues) and cues[ci]['end']<t:ci+=1
            frame=Image.new('RGB',(W,H),'#102b45');frame.paste(background,(0,48));d=ImageDraw.Draw(frame)
            d.text((28,11),title,font=bold,fill='white')
            if cues[ci]['start']<=t<=cues[ci]['end']+.12:
                for j,line in enumerate(wrap(cues[ci]['text'])):d.text((48,580+j*34),line,font=font,fill='white')
            d.text((48,687),'Capturas reais • narração sintética em português • revisão 25/11/2026',font=small,fill='#b8cedb')
            d.rectangle((0,717,round(W*t/duration),720),fill='#78c7a4')
            p.stdin.write(frame.tobytes())
        print(title,flush=True)
    p.stdin.close();assert p.wait()==0,(HERE/'render_narrado.log').read_text()
(OUT/'TRANSURBAN_GUIA_NARRADO.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n',encoding='utf-8')
meta={'duration_seconds':duration,'voice':'HeyGen Lucilene Clear & Trustworthy, pt-BR, voz sintética','voice_id':'e808da2329754929803c8bd98dc36857','captions':'Palavras e tempos retornados pelo serviço; sem acelerar ou esticar a fala.','captures':'Telas reais do projeto; Supabase capturado em 24/11/2026, demais em 25/11/2026.','timeline':[{'start':s,'asset':a,'chapter':t} for s,a,t,y in scenes],'limits':['Não é gravação ao vivo.','Cadastro com provedor/e-mail não foi testado com nova conta real nesta rodada. SMTP pendente.','Sem comprovação de GPS físico ou integração oficial de telemetria/bilhetagem.']}
(OUT/'VIDEO_NARRADO_FONTES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(str(video),flush=True)
