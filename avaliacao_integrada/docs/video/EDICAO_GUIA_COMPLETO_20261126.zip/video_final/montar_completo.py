from pathlib import Path
import sys,json,subprocess,math
from PIL import Image,ImageDraw,ImageFont
sys.stdout.reconfigure(errors='replace')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=ROOT/'avaliacao_integrada/docs/video'
sys.path.insert(0,str(HERE.parent/'video_runtime'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe();W,H,FPS=1280,720,24
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',28);bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',25);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16)
source=Image.open(HERE/'fontes/nova_senha.jpg').convert('RGB');source=source.crop((source.width//2,0,source.width,source.height));source.thumbnail((690,480),Image.Resampling.LANCZOS)
cards=[('1 • Esqueci minha senha','Disponível em passageiro, motorista e gestão.'),('2 • Peça um NOVO link','Use o e-mail cadastrado. Links antigos podem expirar ou apontar para o endereço anterior.'),('3 • Abra o link mais recente','A tela deve mostrar Crie uma nova senha e a área de origem.'),('4 • Escolha e confirme a senha','Você faz essa etapa. Nenhuma senha real foi alterada pelos testes.'),('5 • Volte para sua área','Após salvar, use o acesso de passageiro, motorista ou gestão correspondente.')]
clip=HERE/'recuperacao_visual.mp4'
cmd=[FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','24','-i','-','-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t','25','-c:v','libx264','-crf','23','-preset','superfast','-threads','2','-pix_fmt','yuv420p','-c:a','aac',str(clip)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for n in range(25*FPS):
 t=n/FPS;i=min(4,int(t//5));elapsed=t%5;ease=1-(1-min(1,elapsed/.35))**3
 im=Image.new('RGB',(W,H),'#102b45');d=ImageDraw.Draw(im);d.text((34,18),'RECUPERAÇÃO CORRIGIDA • 26/11/2026',font=bold,fill='white')
 im.paste(source,(W-source.width-30,90));x=round(-30+64*ease)
 d=ImageDraw.Draw(im);d.text((x,150),cards[i][0],font=bold,fill='#f0bf60')
 words=cards[i][1].split();line='';y=210
 for word in words:
  candidate=(line+' '+word).strip()
  if d.textlength(candidate,font=font)>450 and line:d.text((34,y),line,font=font,fill='white');y+=38;line=word
  else:line=candidate
 d.text((34,y),line,font=font,fill='white')
 d.text((34,640),'Trecho visual sem nova narração • formulário testado com token fictício',font=small,fill='#b8cedb')
 d.text((34,669),'O teste de mudança da sua senha deve ser concluído por você.',font=small,fill='#b8cedb')
 d.line((34,704,W-34,704),fill='#29485c',width=4);d.line((34,704,34+round((W-68)*t/25),704),fill='#78c7a4',width=4)
 p.stdin.write(im.tobytes())
p.stdin.close();assert p.wait()==0
# A narração aceita é reutilizada a 1x. Cortes excluem a frase antiga sobre envio de e-mail.
base=OUT/'TRANSURBAN_COMO_ENTRAR_E_USAR.mp4';technical=OUT/'TRANSURBAN_VIDEO_EQUIPE.mp4'
graph=';'.join([
"[0:v]trim=0:39.35,setpts=PTS-STARTPTS,drawbox=x=0:y=558:w=1280:h=90:color=0x102b45:t=fill:enable='gte(t,35.262)'[v0];[0:a]atrim=0:39.35,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a0]",
'[1:v]setpts=PTS-STARTPTS[v1]','[1:a]asetpts=PTS-STARTPTS[a1]',
"[0:v]trim=44.35:221.45,setpts=PTS-STARTPTS,drawbox=x=0:y=558:w=1280:h=90:color=0x102b45:t=fill:enable='lt(t,1.95)+gte(t,174.4)'[v2];[0:a]atrim=44.35:221.45,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a2]",
"[2:v]trim=198.39:296.30,setpts=PTS-STARTPTS,drawbox=x=0:y=558:w=1280:h=90:color=0x102b45:t=fill:enable='lt(t,2)+gte(t,94)'[v3];[2:a]atrim=198.39:296.30,asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a3]",
'[v0][a0][v1][a1][v2][a2][v3][a3]concat=n=4:v=1:a=1[v][a]'])
result=OUT/'TRANSURBAN_GUIA_COMPLETO_20261126.mp4'
subprocess.run([FF,'-hide_banner','-loglevel','error','-y','-i',str(base),'-i',str(clip),'-i',str(technical),'-filter_complex',graph,'-map','[v]','-map','[a]','-c:v','libx264','-preset','superfast','-crf','23','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(result)],check=True)
meta={'data':'2026-11-26','arquivo':result.name,'duracao_prevista_segundos':339.36,'partes':[{'fonte':base.name,'inicio':0,'fim':39.35},{'fonte':'recuperacao_visual.mp4','inicio':0,'fim':25},{'fonte':base.name,'inicio':44.35,'fim':221.45},{'fonte':technical.name,'inicio':198.39,'fim':296.30}],'voz':'Narrações HeyGen pt-BR previamente geradas, reutilizadas a 1x. Nova geração recusada por insuficiência de saldo gratuito.','limites':['Seção de recuperação é visual, sem nova narração.','Sem escuta contínua verificada nesta etapa.','Nenhuma senha real foi alterada nos testes.','Captura da central vazia precede os pedidos atuais.'],'testes':{'api':62,'javascript':47,'tabelas_supabase_http200':12}}
(OUT/'GUIA_COMPLETO_FONTES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(str(result),flush=True)
