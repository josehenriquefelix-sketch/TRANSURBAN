from pathlib import Path
import json,subprocess,sys,re,unicodedata,math,zipfile
sys.stdout.reconfigure(errors='replace')
from PIL import Image,ImageDraw,ImageFont
HERE=Path(__file__).resolve().parent
REPO=HERE.parent
sys.path.insert(0,str(HERE.parent/'video_runtime'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
OUT=REPO/'avaliacao_integrada/docs/video'
data=json.loads((HERE/'voz.json').read_text(encoding='utf-8'))
chars=data['original_characters'];words=data['original_words']
def normal(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower()) if c.isalnum())
corpus='';indices=[]
for c in chars:
    n=normal(c['text']);corpus+=n;indices.extend([c['start_time']]*len(n))
def at(text):
    i=corpus.find(normal(text));assert i>=0,text
    return max(0,indices[i]-.15)
scenes=[
 (0,'passageiro.jpg','Como usar • passageiro, motorista e gestão',0),
 (at('Comece pelo login'),'passageiro_login.jpg','1 • e-mail ou CPF, senha e Entrar',0),
 (at('O campo aceita'),'passageiro_login.jpg','Um identificador por vez • e-mail ou CPF',150),
 (at('Se a senha estiver errada'),'passageiro_login.jpg','Confira os dados • recuperação por e-mail',280),
 (at('Para entrar na gestão'),'gestao_login.jpg','2 • entrar com a conta responsável',0),
 (at('Digite o e-mail dessa conta'),'gestao_login.jpg','Gestão • preencha os dois campos e entre',150),
 (at('Uma Conta Google pessoal'),'gestao_login.jpg','Conta conectada não significa vínculo aprovado',280),
 (at('Depois que a conta responsável'),'autorizacoes.jpg','3 • Autorizar profissionais no menu da gestão',0),
 (at('Quando houver um pedido'),'autorizacoes.jpg','Confira o pedido antes de decidir',0),
 (at('Escolha o escopo de atendimento'),'autorizacoes.jpg','Escopo → justificativa → aprovar ou recusar',0),
 (at('Na entrada do motorista'),'motorista_login.jpg','4 • entrar ou criar conta de motorista',0),
 (at('Depois de autorizado'),'motorista.jpg','Motorista • modelo, número, linha e sentido',650),
 (at('Com o veículo parado'),'motorista.jpg','Motorista • iniciar e encerrar a viagem',1000),
 (at('No passageiro'),'sarandi_inicio.jpg','5 • escolher cidade e linha',0),
 (at('Sarandi também mostra'),'sarandi.jpg','Sarandi • ligações documentadas e identificadas',0),
 (at('Selecione a linha e abra'),'sarandi_horarios.jpg','Passageiro • sentido e dia de operação',0),
 (at('Para criar conta com o formulário'),'cadastro_gestao.jpg','6 • cadastro com CPF, e-mail e senha',0),
 (at('Use pelo menos oito caracteres'),'cadastro_gestao.jpg','Senha • maiúscula, minúscula, número e símbolo',300),
 (at('Se preferir'),'cadastro_gestao.jpg','Google • escolha sua conta na página do Google',0),
 (at('Se faltar autorização profissional'),'autorizacoes.jpg','Solicite ou consulte seu vínculo • sem senha Google',0),
 (at('Por fim'),'passageiro.jpg','7 • sair da conta e usar em outro dispositivo',0),
 (at('Na apresentação'),'passageiro.jpg','Dados privados ficam fora do vídeo e da apresentação',0),
]
duration=data['duration'];W,H,FPS=1280,720,24;VH=510
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',27)
bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',23)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
measure=ImageDraw.Draw(Image.new('RGB',(W,H)))
def wrap(text):
    lines=[];line=''
    for word in text.split():
        candidate=(line+' '+word).strip()
        if measure.textlength(candidate,font=font)>W-96 and line:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    assert len(lines)<=2,(text,lines)
    return lines
def phrase(group):
    start=group[0]['start_time'];end=group[-1]['end_time']
    raw=''.join(c['text'] for c in chars if start-.005<=c['start_time']<=end+.005).strip()
    return {'start':start,'end':end,'text':raw or ' '.join(w['text'] for w in group)}
cues=[];group=[]
for word in words:
    if group and (len(' '.join(x['text'] for x in group+[word]))>102 or word['start_time']-group[0]['start_time']>5.5):
        cues.append(phrase(group));group=[]
    group.append(word)
if group:cues.append(phrase(group))
def stamp(s):
    m=round(s*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'

# Reprodução das formas do logo-passageiro.svg existente; não representa GPS.
logo=Image.new('RGBA',(256,256));ld=ImageDraw.Draw(logo)
ld.rounded_rectangle((0,0,255,255),radius=76,fill='#082b3f')
ld.rounded_rectangle((92,64,188,184),radius=28,fill='#f4fbf7')
ld.rounded_rectangle((108,84,172,128),radius=8,fill='#0a4939')
ld.line((124,96,156,96),fill='white',width=8);ld.line((140,96,140,120),fill='white',width=8)
for cx in (116,164):ld.ellipse((cx-8,148,cx+8,164),fill='#0a4939')
for cx in (112,168):ld.line((cx,184,cx,200),fill='#f4fbf7',width=16)
logo=logo.resize((34,34),Image.Resampling.LANCZOS)
mailCue=at('Digite o e-mail dessa conta');passCue=at('e a senha no campo Senha');enterCue=at('Depois clique em Entrar no painel de gestão')
previous_background=None
video=OUT/'TRANSURBAN_COMO_ENTRAR_E_USAR.mp4'
cmd=[FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(HERE/'narracao.m4a'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','23','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(video)]
with (HERE/'render_narrado.log').open('wb') as log:
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
    ci=0
    for index,(start,asset,title,y) in enumerate(scenes):
        end=scenes[index+1][0] if index+1<len(scenes) else duration
        source=Image.open(HERE/'fontes'/asset).convert('RGB')
        if asset.startswith('cadastro_') or asset.endswith('_login.jpg'):
            source=source.crop((source.width//2,0,source.width,source.height))
        if asset=='banner.png':
            source.thumbnail((W,VH),Image.Resampling.LANCZOS);background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source,((W-source.width)//2,(VH-source.height)//2))
        else:
            scale=600/source.width if asset.startswith('cadastro_') or asset.endswith('_login.jpg') else W/source.width
            source=source.resize((round(source.width*scale),round(source.height*scale)),Image.Resampling.LANCZOS)
            y=max(0,min(round(y*scale),source.height-VH));background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source.crop((0,y,source.width,min(y+VH,source.height))),((W-source.width)//2,0))
        for frameNo in range(round(start*FPS),round(end*FPS)):
            t=frameNo/FPS;elapsed=t-start;progress=max(0,min(1,elapsed/max(.01,end-start)));smooth=progress*progress*(3-2*progress)
            while ci+1<len(cues) and cues[ci]['end']<t:ci+=1
            frame=Image.new('RGB',(W,H),'#102b45')
            # Pan leve de detalhes e transição entre capturas; sem cliques falsos.
            current_y=y
            animated_background=background
            if asset!='banner.png':
                current_y=min(max(0,source.height-VH),y+round(30*smooth))
                animated_background=Image.new('RGB',(W,VH),'#e7edf0')
                animated_background.paste(source.crop((0,current_y,source.width,min(current_y+VH,source.height))),((W-source.width)//2,0))
            if previous_background is not None and elapsed<.24:
                animated_background=Image.blend(previous_background,animated_background,max(0,min(1,elapsed/.24)))
            frame.paste(animated_background,(0,48));d=ImageDraw.Draw(frame)
            entrance=1-(1-min(1,max(0,elapsed/.32)))**3
            d.text((round(-36+64*entrance),11),title,font=bold,fill='white')
            if asset=='gestao_login.jpg':
                highlight=None
                if mailCue<=t<passCue:highlight=(233,281,'E-mail ou CPF')
                elif passCue<=t<enterCue:highlight=(326,376,'Senha')
                elif enterCue<=t<enterCue+3.3:highlight=(438,488,'Entrar')
                if highlight:
                    a,b,label=highlight;xx=(W-source.width)//2;top=48+a*scale-current_y;bottom=48+b*scale-current_y
                    if top>=50 and bottom<=556:
                        box=(int(xx+91*scale),int(top-5),int(xx+543*scale),int(bottom+5))
                        d.rounded_rectangle(box,radius=12,outline='#e5a322',width=4)
                        arrow_y=round((top+bottom)/2);d.line((box[0]-52,arrow_y,box[0]-8,arrow_y),fill='#e5a322',width=5)
                        d.polygon([(box[0]-8,arrow_y),(box[0]-19,arrow_y-9),(box[0]-19,arrow_y+9)],fill='#e5a322')
                        d.text((50,arrow_y-12),label,font=bold,fill='#102b45')
            if cues[ci]['start']<=t<=cues[ci]['end']+.12:
                for j,line in enumerate(wrap(cues[ci]['text'])):d.text((48,580+j*34),line,font=font,fill='white')
            d.line((48,680,W-48,680),fill='#29485c',width=3)
            bx=round(48+(W-96)*t/duration);d.line((48,680,bx,680),fill='#78c7a4',width=3)
            frame.paste(logo,(max(0,min(W-34,bx-17)),650),logo)
            d.text((48,696),'Capturas reais • voz sintética pt-BR • 25/11/2026',font=small,fill='#b8cedb')
            d.text((W-258,696),'Progresso do tutorial',font=small,fill='#b8cedb')
            p.stdin.write(frame.tobytes())
        print(title,flush=True)
        previous_background=animated_background.copy()
    p.stdin.close();assert p.wait()==0,(HERE/'render_narrado.log').read_text()
(OUT/'TUTORIAL_USO_LEGENDAS.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n',encoding='utf-8')
meta={'duration_seconds':duration,'voice':'HeyGen Lucilene Clear & Trustworthy, pt-BR, voz sintética','voice_id':'e808da2329754929803c8bd98dc36857','captions':'Tempos retornados pelo serviço e pontuação dos caracteres originais; sem acelerar ou esticar a fala.','captures':'Telas reais do projeto; Supabase capturado em 24/11/2026, demais em 25/11/2026.','timeline':[{'start':s,'asset':a,'chapter':t} for s,a,t,y in scenes],'limits':['Não é gravação ao vivo. A central sem pedidos é uma captura anterior à chegada dos pedidos atuais.','Cadastro com provedor/e-mail não foi testado com nova conta real nesta rodada. SMTP pendente.','Sem comprovação de GPS físico ou integração oficial de telemetria/bilhetagem.']}
(OUT/'TUTORIAL_USO_FONTES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(str(video),flush=True)
