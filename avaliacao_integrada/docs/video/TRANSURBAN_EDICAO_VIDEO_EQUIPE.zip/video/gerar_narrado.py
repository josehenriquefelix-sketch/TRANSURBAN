from pathlib import Path
import json,subprocess,sys,re,unicodedata,math,zipfile
from PIL import Image,ImageDraw,ImageFont
HERE=Path(__file__).resolve().parent
REPO=HERE.parent
sys.path.insert(0,str(HERE.parent/'video_runtime'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
OUT=REPO/'avaliacao_integrada/docs/video'
data=json.loads((HERE/'voz.json').read_text(encoding='utf-8'))
chars=data['original_characters'];words=data['original_words']
def normal(s):return ''.join(c for c in unicodedata.normalize('NFD',s.lower()) if c.isalnum())
corpus='';indices=[]
for c in chars:
    n=normal(c['text']);corpus+=n;indices.extend([c['start_time']]*len(n))
def at(text):
    i=corpus.find(normal(text));assert i>=0,text
    return max(0,indices[i]-.15)
scenes=[
 (0,'passageiro.jpg','José • apresentação do TRANSURBAN',0),
 (at('A proposta é reunir'),'passageiro.jpg','José • problema, proposta e público',250),
 (at('Bruno apresenta'),'passageiro.jpg','Bruno • cidades, linhas e horários',350),
 (at('Ao escolher Maringá'),'horarios.jpg','Bruno • linhas municipais de Maringá',0),
 (at('Ao escolher Sarandi'),'sarandi.jpg','Bruno • linhas que atendem Sarandi',0),
 (at('A opção Maringá e Sarandi'),'sarandi_inicio.jpg','Bruno • atendimento e ligações metropolitanas',0),
 (at('Depois de escolher a linha'),'sarandi_horarios.jpg','Bruno • linha, sentido e programação',0),
 (at('Cauã apresenta'),'motorista.jpg','Cauã • ônibus, linha e viagem',0),
 (at('Informa o modelo'),'motorista.jpg','Cauã • modelo e número do ônibus',600),
 (at('Para compartilhar a posição'),'motorista.jpg','Cauã • início e encerramento da viagem',1000),
 (at('O mapa depende'),'motorista.jpg','Cauã • permissão e precisão do GPS',650),
 (at('Ana Carolina apresenta'),'gestao.jpg','Ana Carolina • gestão de transporte',0),
 (at('Passageiros e motoristas enviam'),'gestao_mapa.jpg','Ana Carolina • relatos e ocorrências',300),
 (at('Na autorização, a pessoa'),'cadastro_gestao.jpg','Ana Carolina • cadastro e aprovação',0),
 (at('O responsável acessa Autorizar'),'autorizacoes.jpg','Ana Carolina • autorizar profissionais',0),
 (at('O aviso por e-mail'),'autorizacoes.jpg','Ana Carolina • vínculo e aviso por e-mail',0),
 (at('Gustavo apresenta'),'api.jpg','Gustavo • API e comunicação entre as partes',0),
 (at('Por exemplo: quando a tela'),'api_cidades.jpg','Gustavo • exemplo de consulta e JSON',100),
 (at('O catálogo de transporte'),'sarandi.jpg','Gustavo • origem do catálogo de transporte',0),
 (at('Contas, vínculos, viagens'),'supabase.jpg','Gustavo • Supabase e PostgreSQL (captura de 24/11)',0),
 (at('O banco usa PostgreSQL'),'tabelas.jpg','Gustavo • 12 tabelas e relações',0),
 (at('O serviço de autenticação'),'tabelas.jpg','Gustavo • autenticação e estrutura técnica',950),
 (at('Ainda com Gustavo'),'github.jpg','Gustavo • GitHub e execução no VS Code',0),
 (at('Em outro computador'),'github.jpg','Gustavo • configuração no computador da escola',1250),
 (at('O endereço local abre'),'passageiro.jpg','Gustavo • acesso local, celular e limites',0),
 (at('A ordem da apresentação'),'passageiro.jpg','Ordem • José, Bruno, Cauã, Ana Carolina e Gustavo',0),
 (at('O banner mantém'),'banner.png','Equipe • banner original e demonstração sem slides',0),
 (at('Apresentem somente o que está comprovado'),'sarandi.jpg','Equipe • informações verificadas e pendências',0),
 (at('A análise de Ciência de Dados'),'passageiro.jpg','Equipe • base sintética de estudo',0),
]
duration=data['duration'];W,H,FPS=1280,720,24;VH=510
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',27)
bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',23)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
measure=ImageDraw.Draw(Image.new('RGB',(W,H)))
def wrap(text):
    lines=[];line=''
    for word in text.split():
        candidate=(line+' '+word).strip()
        if measure.textlength(candidate,font=font)>W-96 and line:lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    assert len(lines)<=2,(text,lines)
    return lines
def phrase(group):
    start=group[0]['start_time'];end=group[-1]['end_time']
    raw=''.join(c['text'] for c in chars if start-.005<=c['start_time']<=end+.005).strip()
    return {'start':start,'end':end,'text':raw or ' '.join(w['text'] for w in group)}
cues=[];group=[]
for word in words:
    if group and (len(' '.join(x['text'] for x in group+[word]))>102 or word['start_time']-group[0]['start_time']>5.5):
        cues.append(phrase(group));group=[]
    group.append(word)
if group:cues.append(phrase(group))
def stamp(s):
    m=round(s*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'
video=OUT/'TRANSURBAN_VIDEO_EQUIPE.mp4'
cmd=[FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(HERE/'narracao.m4a'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','23','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',str(video)]
with (HERE/'render_narrado.log').open('wb') as log:
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
    ci=0
    for index,(start,asset,title,y) in enumerate(scenes):
        end=scenes[index+1][0] if index+1<len(scenes) else duration
        source=Image.open(HERE/'fontes'/asset).convert('RGB')
        if asset.startswith('cadastro_'):
            source=source.crop((source.width//2,0,source.width,source.height))
        if asset=='banner.png':
            source.thumbnail((W,VH),Image.Resampling.LANCZOS);background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source,((W-source.width)//2,(VH-source.height)//2))
        else:
            scale=min(W/source.width,VH/source.height) if asset.startswith('cadastro_') else W/source.width
            source=source.resize((round(source.width*scale),round(source.height*scale)),Image.Resampling.LANCZOS)
            y=max(0,min(round(y*scale),source.height-VH));background=Image.new('RGB',(W,VH),'#e7edf0');background.paste(source.crop((0,y,source.width,min(y+VH,source.height))),((W-source.width)//2,0))
        for frameNo in range(round(start*FPS),round(end*FPS)):
            t=frameNo/FPS
            while ci+1<len(cues) and cues[ci]['end']<t:ci+=1
            frame=Image.new('RGB',(W,H),'#102b45');frame.paste(background,(0,48));d=ImageDraw.Draw(frame)
            d.text((28,11),title,font=bold,fill='white')
            if cues[ci]['start']<=t<=cues[ci]['end']+.12:
                for j,line in enumerate(wrap(cues[ci]['text'])):d.text((48,580+j*34),line,font=font,fill='white')
            d.text((48,687),'Capturas reais • narração sintética em português • revisão 25/11/2026',font=small,fill='#b8cedb')
            d.rectangle((0,717,round(W*t/duration),720),fill='#78c7a4')
            p.stdin.write(frame.tobytes())
        print(title,flush=True)
    p.stdin.close();assert p.wait()==0,(HERE/'render_narrado.log').read_text()
(OUT/'VIDEO_EQUIPE_LEGENDAS.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n',encoding='utf-8')
meta={'duration_seconds':duration,'voice':'HeyGen Lucilene Clear & Trustworthy, pt-BR, voz sintética','voice_id':'e808da2329754929803c8bd98dc36857','captions':'Tempos retornados pelo serviço e pontuação dos caracteres originais; sem acelerar ou esticar a fala.','captures':'Telas reais do projeto; Supabase capturado em 24/11/2026, demais em 25/11/2026.','timeline':[{'start':s,'asset':a,'chapter':t} for s,a,t,y in scenes],'limits':['Não é gravação ao vivo.','Cadastro com provedor/e-mail não foi testado com nova conta real nesta rodada. SMTP pendente.','Sem comprovação de GPS físico ou integração oficial de telemetria/bilhetagem.']}
(OUT/'VIDEO_EQUIPE_FONTES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(str(video),flush=True)
