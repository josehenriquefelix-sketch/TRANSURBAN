from pathlib import Path
import sys,json,shutil,subprocess,math,re,zipfile
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if (HERE.parent/'video_runtime').exists() else HERE
sys.path.insert(0,str(ROOT/'video_runtime'))
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
REPO=ROOT.parent
OUT=REPO/'avaliacao_integrada/docs/video' if (REPO/'avaliacao_integrada').is_dir() else HERE/'export'
OUT.mkdir(parents=True,exist_ok=True)
FONTE=HERE/'fontes'
for name,source in {
 'motorista.jpg':ROOT/'motorista_desktop_novo_20261125.jpg',
 'gestao.jpg':ROOT/'gestao_desktop_novo_20261125.jpg',
 'gestao_mapa.jpg':ROOT/'gestao_mapa_novo_20261125.jpg',
 'supabase.jpg':REPO/'avaliacao_integrada/docs/imagens/supabase-12-tabelas-20261124.jpg',
 'banner.png':ROOT/'banner_original_90x120_preview.png'
}.items():
    if source.exists() and source.resolve()!=(FONTE/name).resolve():shutil.copy2(source,FONTE/name)

# São capturas reais e textos explicativos; não há simulação de cliques ou GPS.
scenes=[
 ('passageiro.jpg','TRANSURBAN e a proposta',9,0,0,[
  'Este guia mostra as telas reais do TRANSURBAN, um projeto escolar de mobilidade em Maringá e Sarandi.',
  'São três áreas: passageiro, motorista e gestão. O vídeo usa capturas do sistema, não uma gravação ao vivo.']),
 ('passageiro.jpg','Passageiro e consulta de linhas',10,470,600,[
  'No início, o passageiro escolhe o serviço e pesquisa uma linha pelo bairro ou código.',
  'Favoritos, avaliações e suporte usam a conta da pessoa. Consultar uma linha não cria uma viagem.']),
 ('horarios.jpg','Horários e fonte da informação',10,0,70,[
  'A busca por olimpico selecionou a linha 460. O sentido pode ser Terminal / Bairro ou Bairro / Terminal.',
  'O catálogo e os horários citam fontes. Uma partida de terminal não é previsão de chegada a qualquer ponto.']),
 ('login.jpg','Login e autorização profissional',12,0,0,[
  'A pessoa entra com e-mail ou CPF e senha. Cada usuário deve ter sua própria conta.',
  'Motorista e gestão exigem autorização. Confirmação e recuperação por e-mail ainda dependem de SMTP configurado e testado.']),
 ('motorista.jpg','Motorista e identificação do ônibus',10,0,100,[
  'No painel autorizado, o motorista informa o modelo e o número do ônibus que vai conduzir.',
  'A tela também reúne os indicadores do seu perfil. Não foram inventadas notas para preencher o painel.']),
 ('motorista.jpg','Preparar e encerrar a viagem',12,950,1100,[
  'Depois escolhe a linha e o sentido. O início da viagem exige os dados e a permissão solicitada.',
  'As posições compartilhadas vêm do dispositivo autorizado. Ao encerrar a viagem, o compartilhamento termina.']),
 ('gestao.jpg','Gestão e acompanhamento',10,0,170,[
  'A gestão possui um painel separado para acompanhar viagens, avaliações e relatos.',
  'Os indicadores refletem os registros disponíveis. Zero viagens significa que não havia viagem ativa nessa captura.']),
 ('gestao_mapa.jpg','Ocorrências e mapa da gestão',12,130,310,[
  'Passageiros e motoristas enviam relatos. A gestão analisa antes de publicar uma orientação.',
  'Vermelho, amarelo e verde representam condições informadas. Uma área sem marcação não significa trânsito livre.']),
 ('api.jpg','API em Python e FastAPI',9,0,20,[
  'A API recebe os pedidos das telas, confere o acesso e consulta o banco.',
  'O Swagger reúne as rotas. GET consulta; outras operações podem cadastrar, atualizar ou excluir conforme a permissão.']),
 ('api_cidades.jpg','Exemplo real de resposta JSON',11,150,190,[
  'Aqui foi executado GET /cidades. A resposta foi HTTP 200 e retornou Maringá e Sarandi.',
  'JSON é o formato usado para trocar dados entre as telas e a API. Esta é uma resposta capturada em 25/11/2026.']),
 ('supabase.jpg','Supabase e PostgreSQL',10,0,0,[
  'O PostgreSQL do projeto está no Supabase. Esta imagem é um registro da conferência de 24/11/2026.',
  'O sistema usa 12 tabelas ativas. A estrutura foi conferida novamente pelos testes reais de 25/11.']),
 ('tabelas.jpg','Tabelas de cidades linhas e permissões',10,0,180,[
  'Esta é a visualização técnica do banco, sem registros pessoais. Ela fica fora dos painéis dos usuários.',
  'cidade guarda as cidades; linha_onibus guarda os cadastros; tu_acesso define os vínculos profissionais e seus escopos.']),
 ('tabelas.jpg','Tabelas de atendimento e avaliações',10,780,1080,[
  'tu_chamado organiza suporte e relatos. tu_manifestacao guarda avaliações, elogios, reclamações e respostas.',
  'tu_favorito liga usuários às linhas salvas. As chaves evitam duplicações e relacionam os registros.']),
 ('tabelas.jpg','Contas viagens e posições',12,1720,2020,[
  'tu_perfil e tu_motorista representam contas e perfis. tu_pedido_acesso registra a análise dos vínculos.',
  'tu_viagem_operacional e tu_posicao_atual guardam viagens e posições. tu_alerta_operacional registra avisos confirmados.']),
 ('github.jpg','GitHub e organização do código',10,0,280,[
  'O GitHub guarda o código e o histórico. backend, frontend, database, data, docs e tests organizam o projeto.',
  'HTML, CSS e JavaScript fazem as telas. Python e FastAPI fazem a API; pandas atende a parte de estudo de dados.']),
 ('github.jpg','Abrir o projeto em outro computador',12,1240,1450,[
  'Na escola, baixe pelo Git, abra no VS Code e coloque o .env privado em backend. Depois execute o iniciador local.',
  'Python, Git e internet precisam estar disponíveis. O .env e as senhas são levados separadamente; não ficam no GitHub.']),
 ('banner.png','Banner original para impressão',8,0,0,[
  'O banner preserva o layout original. O PDF de impressão tem 90 centímetros de largura por 120 de altura.',
  'O roteiro da equipe é sem slides: cada integrante explica sua parte mostrando os sites e a API.']),
 ('passageiro.jpg','O que apresentar com precisão',14,0,0,[
  'São 66 linhas municipais de Maringá e 22 serviços ou variantes metropolitanos documentados. A lista municipal completa de Sarandi não foi confirmada.',
  'GPS físico e entrega de e-mail não foram comprovados nesta rodada. Não há integração oficial de telemetria ou bilhetagem. O projeto é independente.'])
]
W,H,FPS=1280,720,24
top,viewH,bottom=48,504,168
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',25)
fontB=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',21)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
temp=Image.new('RGB',(W,H));measure=ImageDraw.Draw(temp)
def wrap(value,width,font):
    result=[];line=''
    for word in value.split():
        nxt=(line+' '+word).strip()
        if measure.textbbox((0,0),nxt,font=font)[2]>width and line:result.append(line);line=word
        else:line=nxt
    if line:result.append(line)
    return result
total=sum(x[2] for x in scenes)
video=OUT/'TRANSURBAN_GUIA_PARA_EQUIPE.mp4'
cmd=[FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','23','-threads','2','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-movflags','+faststart',str(video)]
logs=ROOT/'video/render.log'
timeline=[];cues=[];offset=0
def stamp(seconds):
    ms=round(seconds*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
with logs.open('wb') as err:
    process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=err)
    try:
        for index,(asset,title,duration,y0,y1,texts) in enumerate(scenes):
            source=Image.open(FONTE/asset).convert('RGB')
            if asset=='banner.png':
                image=source.copy();image.thumbnail((W,viewH),Image.Resampling.LANCZOS);scale=None
            else:
                scale=W/source.width;image=source.resize((W,round(source.height*scale)),Image.Resampling.LANCZOS)
            overlays=[]
            for caption in texts:
                overlay=Image.new('RGB',(W,bottom),'#102b45');draw=ImageDraw.Draw(overlay)
                lines=wrap(caption,W-112,font)
                assert len(lines)<=4,(title,lines)
                yy=20
                for line in lines:draw.text((56,yy),line,font=font,fill='white');yy+=31
                draw.text((56,bottom-28),'Capturas reais · guia visual sem narração · revisão 25/11/2026',font=small,fill='#a9c4ce')
                overlays.append(overlay)
            for n in range(duration*FPS):
                t=n/FPS;progress=n/max(1,duration*FPS-1);smooth=progress*progress*(3-2*progress)
                frame=Image.new('RGB',(W,H),'#102b45');draw=ImageDraw.Draw(frame)
                draw.text((28,12),title,font=fontB,fill='white')
                draw.text((W-110,16),f'{index+1:02}/{len(scenes):02}',font=small,fill='#b7e6cf')
                if scale is None:frame.paste(image,((W-image.width)//2,top+(viewH-image.height)//2))
                else:
                    y=int((y0+(y1-y0)*smooth)*scale);y=max(0,min(y,max(0,image.height-viewH)))
                    crop=image.crop((0,y,W,min(y+viewH,image.height)))
                    frame.paste(crop,(0,top))
                cue=min(len(texts)-1,int(t/(duration/len(texts))))
                frame.paste(overlays[cue],(0,top+viewH))
                # Indicador de progresso editorial, não um controle falso do site.
                draw=ImageDraw.Draw(frame);draw.rectangle((0,H-3,round(W*(offset+t)/total),H),fill='#78c7a4')
                process.stdin.write(frame.tobytes())
            for j,text in enumerate(texts):cues.append({'start':offset+j*duration/len(texts),'end':offset+(j+1)*duration/len(texts),'text':text})
            timeline.append({'asset':asset,'chapter':title,'start':offset,'end':offset+duration,'source_crop_y':[y0,y1],'fit':'contain' if scale is None else 'uniform_scale_and_detail_view','capture':'24/11/2026' if asset=='supabase.jpg' else '25/11/2026'})
            offset+=duration
            print(f'Cena {index+1}/{len(scenes)}: {title}',flush=True)
    finally:process.stdin.close()
    assert process.wait()==0,logs.read_text(errors='replace')
(OUT/'TRANSURBAN_GUIA_LEGENDAS.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n',encoding='utf-8')
manifest={'title':'TRANSURBAN guia visual para equipe','duration_seconds':total,'dimensions':[W,H],'fps':FPS,'audio':'sem narração e sem música','method':'Capturas reais com vistas de detalhes e legendas explicativas; sem cliques simulados ou afirmação de gravação ao vivo.','timeline':timeline,'limits':['Captura do Supabase é de 24/11/2026. Estrutura e catálogo foram conferidos nos testes reais de 25/11/2026.','Sem exposição intencional de senhas, tokens, CPFs ou registros pessoais.','O vídeo não substitui o teste de uso na rede da escola.'],'render_command':'Python com Pillow e imageio-ffmpeg; gerar_tour.py','sources':['Capturas do projeto neste chat','docs/VALIDACAO_ENTREGA_20261125.json','docs/VALIDACAO_LOGINS_20261125.json','ferramentas/estrutura_banco.html']}
(OUT/'VIDEO_GUIA_FONTES_E_CENAS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'VIDEO_GUIA_TEXTOS.txt').write_text('\n\n'.join(f'{c["start"]:.1f}s — {c["text"]}' for c in cues),encoding='utf-8')
# O pacote de edição é local; não contém .env, tokens ou senhas.
with zipfile.ZipFile(OUT/'TRANSURBAN_PROJETO_DO_VIDEO.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(__file__,'gerar_tour.py')
    for p in FONTE.iterdir():
        if p.is_file():z.write(p,'fontes/'+p.name)
    for name in ['VIDEO_GUIA_FONTES_E_CENAS.json','VIDEO_GUIA_TEXTOS.txt','TRANSURBAN_GUIA_LEGENDAS.srt']:z.write(OUT/name,name)
    z.writestr('requirements-video.txt','Pillow\nimageio-ffmpeg\n')
    z.writestr('LEIA_ME.txt','Projeto de edição do guia TRANSURBAN. Windows com Python e fontes Arial. Instale requirements-video.txt em um ambiente separado e execute gerar_tour.py. O vídeo usa capturas reais e legendas, sem áudio ou cliques simulados. Saída: pasta export. Nenhuma credencial é necessária para editar este material.\n')
print(json.dumps({'arquivo':str(video),'duracao_segundos':total,'tamanho_mb':round(video.stat().st_size/1024**2,2)},ensure_ascii=False),flush=True)
